document.addEventListener('DOMContentLoaded', () => {
    // --- Elements ---
    const entryTypeSelect = document.getElementById('entry_type');
    const chargeTypeGroup = document.getElementById('charge-type-group');
    const typeChargeInput = document.getElementById('type_charge');
    const form = document.getElementById('entry-form');
    
    const inputQte = document.getElementById('quantite');
    const inputPU = document.getElementById('prix_unitaire');
    const liveTotal = document.getElementById('live-total');

    const dropZone = document.getElementById('drop-zone');
    const fileInput = document.getElementById('file-input');
    const uploadStatus = document.getElementById('upload-status');

    let financeChart = null;
    let productsChart = null;
    let chargesChart = null;

    // --- Modal Facture Elements ---
    const modal = document.getElementById('invoice-modal');
    const btnOpenModal = document.getElementById('btn-open-invoice');
    const closeBtn = document.querySelector('.close-modal');
    const addInvItemBtn = document.getElementById('add-inv-item');
    const invoiceItemsDiv = document.getElementById('invoice-items');
    const invoiceForm = document.getElementById('invoice-form');

    // --- Modal Logic ---
    if (btnOpenModal) btnOpenModal.onclick = () => modal.style.display = "block";
    if (closeBtn) closeBtn.onclick = () => modal.style.display = "none";
    window.onclick = (e) => { if (e.target == modal) modal.style.display = "none"; }

    if (addInvItemBtn) {
        addInvItemBtn.onclick = () => {
            const row = document.createElement('div');
            row.className = 'invoice-item-row';
            row.style = 'display:flex; gap:10px; margin-bottom:10px;';
            row.innerHTML = `
                <input type="text" class="inv-des" list="designation-list" placeholder="Type de Malhfa" style="flex:2;" required>
                <select class="inv-type-cmd" style="flex:1;" required>
                    <option value="Détail">Détail</option>
                    <option value="Gros">Gros</option>
                </select>
                <input type="number" step="0.01" class="inv-qty" placeholder="Qté" style="flex:1;" required>
                <input type="number" step="0.01" class="inv-pu" placeholder="P.U. (DH)" style="flex:1;" required>
                <button type="button" class="btn btn-danger remove-item" style="padding:0.5rem;"><i class='bx bx-trash'></i></button>
            `;
            invoiceItemsDiv.appendChild(row);
            row.querySelector('.remove-item').onclick = () => row.remove();
        };
    }

    if (invoiceForm) {
        invoiceForm.onsubmit = async (e) => {
            e.preventDefault();
            const client_name = document.getElementById('client_name').value;
            const client_ice = document.getElementById('client_ice').value;
            const client_phone = document.getElementById('client_phone').value;
            const client_address = document.getElementById('client_address').value;
            
            const itemRows = document.querySelectorAll('.invoice-item-row');
            const items = [];
            itemRows.forEach(row => {
                items.push({
                    designation: row.querySelector('.inv-des').value,
                    type_commande: row.querySelector('.inv-type-cmd').value,
                    quantite: parseFloat(row.querySelector('.inv-qty').value),
                    prix_unitaire: parseFloat(row.querySelector('.inv-pu').value)
                });
            });

            const payload = { client_name, client_ice, client_phone, client_address, items };

            try {
                const response = await fetch('/api/invoice/generate', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(payload)
                });

                if (response.ok) {
                    const blob = await response.blob();
                    const url = window.URL.createObjectURL(blob);
                    const a = document.createElement('a');
                    a.href = url;
                    a.download = "Facture_Client_" + client_name + ".pdf";
                    document.body.appendChild(a);
                    a.click();
                    a.remove();
                    modal.style.display = "none";
                    invoiceForm.reset();
                } else {
                    alert("Erreur lors de la génération de la facture.");
                }
            } catch (err) {
                console.error(err);
            }
        };
    }

    // --- Init ---
    fetchDashboard();
    fetchHistory();

    // --- Live Calculation ---
    function updateLiveTotal() {
        const qte = parseFloat(inputQte.value) || 0;
        const pu = parseFloat(inputPU.value) || 0;
        const total = qte * pu;
        liveTotal.textContent = total.toFixed(2) + ' DH';
    }

    inputQte.addEventListener('input', updateLiveTotal);
    inputPU.addEventListener('input', updateLiveTotal);

    const designationList = document.getElementById('designation-list');
    const optionsProduit = ["Malhaf Double", "Malha Simple", "Malhfa personnalisée"];
    const optionsCharge = ["Achat", "Transport", "Frais douane", "Controleur Douane", "Taxe Douane", "Transitaire", "Transport local", "Charge du retard"];

    function updateDatalist() {
        if (!designationList) return;
        designationList.innerHTML = '';
        const options = entryTypeSelect.value === 'produit' ? optionsProduit : optionsCharge;
        options.forEach(opt => {
            const el = document.createElement('option');
            el.value = opt;
            designationList.appendChild(el);
        });
    }

    // Init datalist on load
    updateDatalist();

    entryTypeSelect.addEventListener('change', (e) => {
        updateDatalist();
        if (e.target.value === 'charge') {
            chargeTypeGroup.style.display = 'block';
        } else {
            chargeTypeGroup.style.display = 'none';
            typeChargeInput.value = '';
        }
    });

    // --- Form Submit ---
    form.addEventListener('submit', async (e) => {
        e.preventDefault();
        
        const data = {
            entry_type: entryTypeSelect.value,
            designation: document.getElementById('designation').value,
            quantite: parseFloat(inputQte.value),
            prix_unitaire: parseFloat(inputPU.value),
            type_charge: typeChargeInput.value || null
        };

        try {
            const response = await fetch('/api/entry', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(data)
            });

            if (response.ok) {
                form.reset();
                updateLiveTotal();
                entryTypeSelect.dispatchEvent(new Event('change')); // reset UI
                fetchDashboard();
                fetchHistory();
            } else {
                alert('Erreur lors de l\'ajout.');
            }
        } catch (error) {
            console.error(error);
        }
    });

    // --- Drag and Drop Logic ---
    dropZone.addEventListener('dragover', (e) => {
        e.preventDefault();
        dropZone.classList.add('dragover');
    });
    dropZone.addEventListener('dragleave', () => {
        dropZone.classList.remove('dragover');
    });
    dropZone.addEventListener('drop', (e) => {
        e.preventDefault();
        dropZone.classList.remove('dragover');
        if (e.dataTransfer.files.length) {
            handleFileUpload(e.dataTransfer.files[0]);
        }
    });
    fileInput.addEventListener('change', (e) => {
        if (e.target.files.length) {
            handleFileUpload(e.target.files[0]);
        }
    });

    async function handleFileUpload(file) {
        if (!file.name.endsWith('.xlsx')) {
            uploadStatus.textContent = 'Erreur : Veuillez uploader un fichier .xlsx';
            uploadStatus.className = 'status-msg error';
            return;
        }

        const formData = new FormData();
        formData.append('file', file);
        uploadStatus.textContent = 'Importation en cours...';
        uploadStatus.className = 'status-msg';

        try {
            const response = await fetch('/api/upload', {
                method: 'POST',
                body: formData
            });
            const result = await response.json();
            
            if (response.ok) {
                uploadStatus.textContent = `Succès : ${result.inserted} entrées importées !`;
                uploadStatus.className = 'status-msg success';
                fetchDashboard();
                fetchHistory();
            } else {
                uploadStatus.textContent = result.detail || 'Erreur lors de l\'import';
                uploadStatus.className = 'status-msg error';
            }
        } catch (error) {
            uploadStatus.textContent = 'Erreur réseau';
            uploadStatus.className = 'status-msg error';
        }
    }

    // --- Fetch Dashboard ---
    async function fetchDashboard() {
        try {
            const response = await fetch('/api/dashboard');
            const data = await response.json();
            
            document.getElementById('kpi-ca').textContent = data.ca_total.toFixed(2) + ' DH';
            document.getElementById('kpi-charges').textContent = data.charges_cumulees.toFixed(2) + ' DH';
            document.getElementById('kpi-benefice').textContent = data.benefice_brut.toFixed(2) + ' DH';
            document.getElementById('kpi-marge').textContent = data.marge_moyenne + ' %';

            updateChart(data.trends, data.breakdown);
        } catch(error) {
            console.error('Erreur stats', error);
        }
    }

    // --- Chart.js ---
    function updateChart(trends, breakdown) {
        const ctx = document.getElementById('financeChart').getContext('2d');
        
        // Merge and sort unique dates
        const allDates = [...new Set([...trends.sales_dates, ...trends.charges_dates])].sort();
        
        // Map data to dates
        const salesData = allDates.map(date => {
            const idx = trends.sales_dates.indexOf(date);
            return idx !== -1 ? trends.sales_totals[idx] : 0;
        });
        
        const chargesData = allDates.map(date => {
            const idx = trends.charges_dates.indexOf(date);
            return idx !== -1 ? trends.charges_totals[idx] : 0;
        });

        if (financeChart) { financeChart.destroy(); }
        
        // Dark theme tweaks for Chart.js
        Chart.defaults.color = '#495057';
        Chart.defaults.borderColor = '#e9ecef';

        financeChart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: allDates,
                datasets: [
                    {
                        label: 'Revenus (DH)',
                        data: salesData,
                        borderColor: '#10b981',
                        backgroundColor: 'rgba(16, 185, 129, 0.1)',
                        borderWidth: 2,
                        tension: 0.4,
                        fill: true
                    },
                    {
                        label: 'Charges (DH)',
                        data: chargesData,
                        borderColor: '#ef4444',
                        backgroundColor: 'rgba(239, 68, 68, 0.1)',
                        borderWidth: 2,
                        tension: 0.4,
                        fill: true
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { position: 'top' }
                },
                scales: {
                    y: { beginAtZero: true }
                }
            }
        });

        // Diagrammes circulaires
        if (productsChart) { productsChart.destroy(); }
        if (chargesChart) { chargesChart.destroy(); }

        const pCtx = document.getElementById('productsChart').getContext('2d');
        productsChart = new Chart(pCtx, {
            type: 'doughnut',
            data: {
                labels: breakdown.products_labels,
                datasets: [{
                    data: breakdown.products_totals,
                    backgroundColor: ['#10b981', '#34d399', '#059669', '#6ee7b7', '#a7f3d0']
                }]
            },
            options: { responsive: true, maintainAspectRatio: false }
        });

        const cCtx = document.getElementById('chargesChart').getContext('2d');
        chargesChart = new Chart(cCtx, {
            type: 'doughnut',
            data: {
                labels: breakdown.charges_labels,
                datasets: [{
                    data: breakdown.charges_totals,
                    backgroundColor: ['#ef4444', '#f87171', '#dc2626', '#fca5a5', '#b91c1c']
                }]
            },
            options: { responsive: true, maintainAspectRatio: false }
        });
    }

    // --- Fetch History ---
    async function fetchHistory() {
        try {
            const response = await fetch('/api/history');
            const data = await response.json();
            
            const tbody = document.querySelector('#history-table tbody');
            tbody.innerHTML = '';
            
            let sumProduits = 0;
            let sumCharges = 0;
            
            data.forEach(entry => {
                if (entry.entry_type === 'produit') {
                    sumProduits += entry.prix_total;
                } else {
                    sumCharges += entry.prix_total;
                }

                const tr = document.createElement('tr');
                const date = new Date(entry.created_at).toLocaleString('fr-FR', {dateStyle:'short', timeStyle:'short'});
                const badgeClass = entry.entry_type === 'produit' ? 'badge-produit' : 'badge-charge';
                const typeText = entry.entry_type === 'produit' ? 'Produit' : 'Charge';
                
                tr.innerHTML = `
                    <td>${date}</td>
                    <td><span class="badge ${badgeClass}">${typeText}</span></td>
                    <td>${entry.designation}</td>
                    <td>${entry.quantite}</td>
                    <td>${entry.prix_unitaire.toFixed(2)} DH</td>
                    <td><strong>${entry.prix_total.toFixed(2)} DH</strong></td>
                    <td>${entry.type_charge || '-'}</td>
                    <td>
                        <button class="btn btn-danger" onclick="deleteEntry(${entry.id})" title="Supprimer">
                            <i class='bx bx-trash'></i>
                        </button>
                    </td>
                `;
                tbody.appendChild(tr);
            });
            
            const elmProduits = document.getElementById('history-total-produits');
            const elmCharges = document.getElementById('history-total-charges');
            if (elmProduits) elmProduits.textContent = sumProduits.toFixed(2) + ' DH (Revenus)';
            if (elmCharges) elmCharges.textContent = sumCharges.toFixed(2) + ' DH (Charges)';
            
        } catch(error) {
            console.error('Erreur history', error);
        }
    }

    // Make it globally accessible for inline onclick handlers
    window.deleteEntry = async function(id) {
        if (!confirm("Voulez-vous vraiment supprimer cette entrée de l'historique ?")) return;
        
        try {
            const response = await fetch(`/api/history/${id}`, { method: 'DELETE' });
            if (response.ok) {
                fetchDashboard();
                fetchHistory();
            }
        } catch (error) {
            console.error(error);
        }
    };
});
