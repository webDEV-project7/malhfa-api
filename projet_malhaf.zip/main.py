from fastapi import FastAPI, Depends, Request, UploadFile, File, Form, HTTPException
from fastapi.responses import HTMLResponse, StreamingResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session
from sqlalchemy import func
from typing import List
import pandas as pd
import io

from fpdf import FPDF
import datetime

import models, schemas
from database import engine, get_db

# Creation of tables if they don't exist
models.Base.metadata.create_all(bind=engine)

app = FastAPI(title="Gestion Financière API")

app.mount("/static", StaticFiles(directory="static"), name="static")
templates = Jinja2Templates(directory="templates")

@app.get("/", response_class=HTMLResponse)
def index(request: Request):
    return templates.TemplateResponse(request=request, name="index.html")

@app.post("/api/entry", response_model=schemas.EntryResponse)
def create_entry(entry: schemas.EntryCreate, db: Session = Depends(get_db)):
    prix_total = entry.quantite * entry.prix_unitaire
    db_entry = models.Entry(
        entry_type=entry.entry_type,
        designation=entry.designation,
        quantite=entry.quantite,
        prix_unitaire=entry.prix_unitaire,
        prix_total=prix_total,
        type_charge=entry.type_charge
    )
    db.add(db_entry)
    db.commit()
    db.refresh(db_entry)
    return db_entry

@app.post("/api/upload")
async def upload_excel(file: UploadFile = File(...), db: Session = Depends(get_db)):
    if not file.filename.endswith('.xlsx'):
        raise HTTPException(status_code=400, detail="Seuls les fichiers .xlsx sont acceptés")
    
    contents = await file.read()
    try:
        # We expect a sheet for or format like: Type, Designation, Quantite, Prix Unitaire, Type Charge
        df = pd.read_excel(io.BytesIO(contents))
        
        added_entries = []
        for index, row in df.iterrows():
            quantite = float(row.get("Quantité", 0))
            prix_unitaire = float(row.get("Prix unitaire", 0))
            prix_total = quantite * prix_unitaire
            
            entry_type = str(row.get("Type d'entrée", "produit")).lower()
            if "produit" not in entry_type and "charge" not in entry_type:
                continue # skip invalid rows
            
            db_entry = models.Entry(
                entry_type="produit" if "produit" in entry_type else "charge",
                designation=str(row.get("Désignation", "")),
                quantite=quantite,
                prix_unitaire=prix_unitaire,
                prix_total=prix_total,
                type_charge=str(row.get("Type de charge", "")) if pd.notna(row.get("Type de charge")) else None
            )
            db.add(db_entry)
            added_entries.append(db_entry)
            
        db.commit()
        return {"status": "success", "inserted": len(added_entries)}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Erreur de lecture: {str(e)}")

@app.get("/api/dashboard")
def get_dashboard(db: Session = Depends(get_db)):
    # Calculate global metrics
    produits_total = db.query(func.sum(models.Entry.prix_total)).filter(models.Entry.entry_type == "produit").scalar() or 0
    charges_total = db.query(func.sum(models.Entry.prix_total)).filter(models.Entry.entry_type == "charge").scalar() or 0
    
    benefice_brut = produits_total - charges_total
    marge_moyenne = (benefice_brut / produits_total * 100) if produits_total > 0 else 0

    # Trend data simple (grouped by date)
    sales_trend = db.query(
        func.date(models.Entry.created_at).label('date'),
        func.sum(models.Entry.prix_total).label('total')
    ).filter(models.Entry.entry_type == 'produit').group_by(func.date(models.Entry.created_at)).all()

    charges_trend = db.query(
        func.date(models.Entry.created_at).label('date'),
        func.sum(models.Entry.prix_total).label('total')
    ).filter(models.Entry.entry_type == 'charge').group_by(func.date(models.Entry.created_at)).all()

    # Products breakdown
    products_breakdown = db.query(
        models.Entry.designation,
        func.sum(models.Entry.prix_total).label('total')
    ).filter(models.Entry.entry_type == 'produit').group_by(models.Entry.designation).all()

    # Charges breakdown
    charges_breakdown = db.query(
        models.Entry.designation,
        func.sum(models.Entry.prix_total).label('total')
    ).filter(models.Entry.entry_type == 'charge').group_by(models.Entry.designation).all()

    return {
        "ca_total": produits_total,
        "charges_cumulees": charges_total,
        "benefice_brut": benefice_brut,
        "marge_moyenne": round(marge_moyenne, 2),
        "trends": {
            "sales_dates": [str(d.date) for d in sales_trend],
            "sales_totals": [float(d.total) for d in sales_trend],
            "charges_dates": [str(d.date) for d in charges_trend],
            "charges_totals": [float(d.total) for d in charges_trend],
        },
        "breakdown": {
            "products_labels": [d.designation for d in products_breakdown],
            "products_totals": [float(d.total) for d in products_breakdown],
            "charges_labels": [d.designation for d in charges_breakdown],
            "charges_totals": [float(d.total) for d in charges_breakdown],
        }
    }

@app.get("/api/history", response_model=List[schemas.EntryResponse])
def get_history(db: Session = Depends(get_db)):
    return db.query(models.Entry).order_by(models.Entry.created_at.desc()).all()

@app.delete("/api/history/{entry_id}")
def delete_entry(entry_id: int, db: Session = Depends(get_db)):
    entry = db.query(models.Entry).filter(models.Entry.id == entry_id).first()
    if not entry:
        raise HTTPException(status_code=404, detail="Entrée introuvable")
    db.delete(entry)
    db.commit()
    return {"status": "success", "deleted_id": entry_id}

@app.get("/api/template")
def download_template():
    df = pd.DataFrame(columns=["Type d'entrée", "Désignation", "Quantité", "Prix unitaire", "Prix total (Infos)", "Type de charge"])
    # Exemples personnalisés
    df.loc[0] = ["Produit", "Malhaf Double", 10, 100, "=C2*D2", ""]
    df.loc[1] = ["Charge", "Achat", 1, 50, "=C3*D3", "Malhaf Double"]
    df.loc[2] = ["Charge", "Transport", 20, 15, "=C4*D4", "Transport local"]
    df.loc[3] = ["Charge", "Frais douane", 1, 200, "=C5*D5", "Taxe Douane"]
    
    stream = io.BytesIO()
    with pd.ExcelWriter(stream, engine="openpyxl") as writer:
        df.to_excel(writer, index=False)
    stream.seek(0)
    
    return StreamingResponse(stream, media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", headers={"Content-Disposition": "attachment; filename=modele_saisie.xlsx"})

@app.get("/api/export")
def export_history(db: Session = Depends(get_db)):
    entries = db.query(models.Entry).order_by(models.Entry.created_at.desc()).all()
    data = []
    for e in entries:
        data.append({
            "Date": str(e.created_at),
            "Type": e.entry_type,
            "Désignation": e.designation,
            "Quantité": e.quantite,
            "Prix Unitaire": e.prix_unitaire,
            "Prix Total": e.prix_total,
            "Type de Charge": e.type_charge
        })
    df = pd.DataFrame(data)
    stream = io.BytesIO()
    with pd.ExcelWriter(stream, engine="openpyxl") as writer:
        df.to_excel(writer, index=False)
    stream.seek(0)
    
    return StreamingResponse(stream, media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", headers={"Content-Disposition": "attachment; filename=historique.xlsx"})

@app.post("/api/invoice/generate")
def generate_invoice(request: schemas.InvoiceRequest):
    pdf = FPDF()
    pdf.add_page()
    pdf.set_font("helvetica", "B", 16)
    
    # Header
    pdf.cell(0, 10, "FACTURE / BON DE COMMANDE", align="C", new_x="LMARGIN", new_y="NEXT")
    pdf.ln(5)
    
    pdf.set_font("helvetica", "", 12)
    pdf.cell(0, 8, f"Date: {datetime.datetime.now().strftime('%Y-%m-%d')}", new_x="LMARGIN", new_y="NEXT")
    pdf.cell(0, 8, f"Client: {request.client_name}", new_x="LMARGIN", new_y="NEXT")
    if request.client_ice:
        pdf.cell(0, 8, f"ICE: {request.client_ice}", new_x="LMARGIN", new_y="NEXT")
    if request.client_phone:
        pdf.cell(0, 8, f"Telephone: {request.client_phone}", new_x="LMARGIN", new_y="NEXT")
    if request.client_address:
        pdf.cell(0, 8, f"Adresse: {request.client_address}", new_x="LMARGIN", new_y="NEXT")
    
    pdf.ln(10)
    
    # Table Header
    pdf.set_font("helvetica", "B", 12)
    pdf.cell(60, 10, "Designation", border=1)
    pdf.cell(20, 10, "Type", border=1, align="C")
    pdf.cell(20, 10, "Qte", border=1, align="C")
    pdf.cell(45, 10, "Prix Unitaire", border=1, align="C")
    pdf.cell(45, 10, "Total", border=1, align="C", new_x="LMARGIN", new_y="NEXT")
    
    # Table rows
    pdf.set_font("helvetica", "", 12)
    total_facture = 0
    for item in request.items:
        ligne_total = item.quantite * item.prix_unitaire
        total_facture += ligne_total
        # Ensure utf-8 strings for PDF (FPDF2 supports native python strings usually)
        pdf.cell(60, 10, item.designation, border=1)
        pdf.cell(20, 10, item.type_commande, border=1, align="C")
        pdf.cell(20, 10, str(item.quantite), border=1, align="C")
        pdf.cell(45, 10, f"{item.prix_unitaire:.2f} DH", border=1, align="C")
        pdf.cell(45, 10, f"{ligne_total:.2f} DH", border=1, align="C", new_x="LMARGIN", new_y="NEXT")
        
    pdf.ln(5)
    pdf.set_font("helvetica", "B", 12)
    pdf.cell(145, 10, "TOTAL A PAYER:", border=1, align="R")
    pdf.cell(45, 10, f"{total_facture:.2f} DH", border=1, align="C", new_x="LMARGIN", new_y="NEXT")
    
    # Output to bytearray
    pdf_bytes = pdf.output()
    
    return StreamingResponse(
        io.BytesIO(pdf_bytes), 
        media_type="application/pdf", 
        headers={"Content-Disposition": 'attachment; filename="facture.pdf"'}
    )
