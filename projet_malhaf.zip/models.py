from sqlalchemy import Column, Integer, String, Float, DateTime
from database import Base
from datetime import datetime, timezone

class Entry(Base):
    __tablename__ = "entries"

    id = Column(Integer, primary_key=True, index=True)
    entry_type = Column(String(50), index=True) # "produit" ou "charge"
    designation = Column(String(255))
    quantite = Column(Float)
    prix_unitaire = Column(Float)
    prix_total = Column(Float)
    type_charge = Column(String(255), nullable=True) # Ex: "Transport", "Douane", etc.
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))
