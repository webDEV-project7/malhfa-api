from pydantic import BaseModel
from typing import Optional
from datetime import datetime

class EntryBase(BaseModel):
    entry_type: str
    designation: str
    quantite: float
    prix_unitaire: float
    type_charge: Optional[str] = None

class EntryCreate(EntryBase):
    pass

class EntryResponse(EntryBase):
    id: int
    prix_total: float
    created_at: datetime
    
    class Config:
        from_attributes = True

class InvoiceItem(BaseModel):
    designation: str
    type_commande: str
    quantite: float
    prix_unitaire: float

class InvoiceRequest(BaseModel):
    client_name: str
    client_ice: Optional[str] = ""
    client_address: Optional[str] = ""
    client_phone: Optional[str] = ""
    items: list[InvoiceItem]
